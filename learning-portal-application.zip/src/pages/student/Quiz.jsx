import QuizForm from 'components/student/quiz/QuizForm';

/* eslint-disable react/no-unescaped-entities */
export default function Quiz() {
  return (
    <section className="py-6 bg-primary">
      <QuizForm />
    </section>
  );
}
