export default function Error({ message }) {
  return (
    <div>
      <h2>{message}</h2>
    </div>
  );
}
