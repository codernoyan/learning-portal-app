export default function TableLoading() {
  return (
    <tr className="border-2 border-gray-700">
      <th className="table-th !text-center">Loading...</th>
      <th className="table-th !text-center">Loading...</th>
      <th className="table-th !text-center">Loading...</th>
      <th className="table-th !text-center">Loading...</th>
      <th className="table-th !text-center">Loading...</th>
    </tr>
  );
}
