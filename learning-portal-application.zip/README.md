# batch-2---final-exam---edtech-platform-codernoyan
